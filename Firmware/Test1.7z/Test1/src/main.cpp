
#include "msp430f2013.h"

#include <stdint.h>


void lightOFF(void){
        P1OUT &= ~((1<<6)+(1<<7)+(1<<5));
	P2OUT &= ~((1<<6)+(1<<7));
}
void lightA(void){
  	P1OUT |= (1<<5);
	P2OUT &= ~((1<<6)+(1<<7));
	P1OUT &= ~((1<<6)+(1<<7));
}
void lightB(void){
  	P1OUT |= (1<<5)+(1<<6);
	P1OUT &= ~((1<<7));
	P2OUT &= ~((1<<6)+(1<<7));
}
void lightC(void){
  	P1OUT |= (1<<5)+(1<<6)+(1<<7);
	P2OUT &= ~((1<<6)+(1<<7));
}
void lightD(void){
  	P1OUT |= (1<<5)+(1<<6)+(1<<7);
  	P2OUT |= (1<<7);
	P2OUT &= ~(1<<6);
}
void lightE(void){
  	P1OUT |= (1<<5)+(1<<6)+(1<<7);
  	P2OUT |= (1<<7)+(1<<6);
}




enum AdcState{
 	IDLE=0, 
	SAMPLING_BATTERY,
	SAMPLING_CHARGER,
	SAMPLING_TEMPERATURE,
};
AdcState adcState = IDLE;

void startAdcConversion(){
	SD16CCTL0 = 
	  	(1<<13)+//High-impedance input buffer mode, Slow speed/current
		(1<<12)+//Unipolar mode
		(1<<10)+//Single conversion mode
		(0<<8)+//Oversampling ratio=256
		(1<<7)+//LSB toggle
		(1<<1)+//Start conversion
	  	0;  
}
#define adcConversionIsDone		((SD16CCTL0&(1<<2))!=0)
  
uint16_t adcResultBattery = 0;
uint16_t adcResultBatteryFiltered = 0;
uint16_t adcResultCharger = 0;
uint16_t adcResultTemperature = 0;

bool batteryIsGood = false;
bool chargerIsActive = false;
const uint16_t BATTERY_GOOD_THRESHOLD = 40000;	
const uint16_t CHARGER_ACTIVE_THRESHOLD = 55000;	


//=================================================================================================
int main(void)
{
	WDTCTL = WDTPW + WDTHOLD;
  
	{
	//PORTS
	
	  /*
	  1		VCC		+2.5V
	  2		P1.0	A0+		battery voltage
	  3		P1.1	A0-		gnd
	  4		P1.2	A1+		???
	  5		P1.3	A1-		gnd
	  6		P1.4	INPUT	button, active low
	  7		P1.5	OUTPUT	powerON, active high
	  8		P1.6	OUTPUT	light40, active high
	  9		P1.7	OUTPUT	light60, active high
	  10	RST
	  11	TEST
	  12	P2.7	OUTPUT	light80, active high
	  13	P2.6	OUTPUT	light100, active high
	  14	VSS		gnd
	  */
		  
		P1DIR = 
		  	(0<<4)+//button in
		  	(1<<5)+//light out
		  	(1<<6)+//light40
		  	(1<<7)+//light60
			0;

		P2DIR = 
		  	(1<<6)+//light80
		  	(1<<7)+//light100
			0;
		
		
		P1REN = 
		  	(1<<4)+//button pull-up
		  	(0<<5)+//light 
			0;
		P2REN =
		  	0;
		
		P2SEL = 
		  	0;
		
		P1OUT = 
		  	(1<<4)+//button pull-up
		  	(0<<5)+//light off
		  	0;
		P2OUT = 
		  	0;
	  
	  	lightOFF();
	  
	}

	
	
  	{
		// TIMER A (heartbeat)
		TA0CTL = 
			TASSEL_2+/* Timer A clock source select: 2 - SMCLK */
			ID_0+/* Timer A input divider: 0 - /1 */
			MC_2+/* Timer A mode control: 2 - Continous up */
			TACLR+/* Timer A counter clear */
			TAIE+/* Timer A counter interrupt enable */
			0;
		__enable_interrupt();

  	}

  	SD16AE = 0x0F;
	
	SD16CTL	= 
	  	SD16XDIV_0+/* SD16 2.Clock Divider Select /1 */
		SD16DIV_3+/* SD16 Clock Divider Select /8 */
		SD16LP+/* SD16 Low Power Mode Enable */
		SD16SSEL_1+/* SD16 Clock Source Select SMCLK */
		SD16REFON+/* SD16 Switch internal Reference on */
	  	0;

	
	
	while(1){
	  
	  	switch(adcState){ 
		case IDLE:
			SD16INCTL0 = 0;//battery channel
			startAdcConversion();
			adcState = SAMPLING_BATTERY;
		  	break;
		case SAMPLING_BATTERY:
			if (adcConversionIsDone){
				adcResultBattery = SD16MEM0;
					adcResultBatteryFiltered /= 8;
					adcResultBatteryFiltered *= 7;
					adcResultBatteryFiltered += (adcResultBattery/8);
				SD16INCTL0 = 1;//charger channel
				startAdcConversion();
				adcState = SAMPLING_CHARGER;
				if (adcResultBatteryFiltered>BATTERY_GOOD_THRESHOLD){
				  	batteryIsGood = true;
				}else{
				  	batteryIsGood = false;
				}
			}
		  	break;
		case SAMPLING_CHARGER:
			if (adcConversionIsDone){
				adcResultCharger = SD16MEM0;
				SD16INCTL0 = 6;//temperature sensor channel
				startAdcConversion();
				adcState = SAMPLING_TEMPERATURE;
				if (adcResultCharger>CHARGER_ACTIVE_THRESHOLD){
					chargerIsActive = true;
				}else{
					chargerIsActive = false;
				}
			}
		  	break;
		case SAMPLING_TEMPERATURE:
			if (adcConversionIsDone){
				adcResultTemperature = SD16MEM0;
				SD16INCTL0 = 0;//battery channel
				startAdcConversion();
				adcState = SAMPLING_BATTERY;
			}
		  	break;
		}
	  
	}
  
  
}


//=================================================================================================
#define buttonIsPressed		((P1IN&(1<<4))==0)

enum LightState{
	OFF=0,
	LIGHT20_PHASE1,	
	LIGHT20_PHASE2,	
	LIGHT40_PHASE1,	
	LIGHT40_PHASE2,	
	LIGHT60_PHASE1,	
	LIGHT60_PHASE2,	
	LIGHT80_PHASE1,	
	LIGHT80_PHASE2,	
	LIGHT100_PHASE1,	
	LIGHT100_PHASE2,	
  
};

const uint16_t LIGHT_ON_DELAY = (1*16);
const uint16_t LIGHT_CHANGE_DELAY = (4);
const uint16_t LIGHT_OFF_DELAY = (2*16);


#pragma vector = TIMER0_A1_VECTOR 
__interrupt void HeartbeatTimerISR(void){

	/* estimated frequency = 16.8Hz or 60ms */  
	TA0CTL = 
		TASSEL_2+/* Timer A clock source select: 2 - SMCLK */
		ID_0+/* Timer A input divider: 0 - /1 */
		MC_2+/* Timer A mode control: 2 - Continous up */
		TAIE+/* Timer A counter interrupt enable */
		0;	

	
	static uint16_t buttonPressedCounter = 0;
	static LightState lightState = OFF;

	if ((batteryIsGood==false)||(chargerIsActive==true)){
		lightOFF();
		lightState = OFF; 	
	}else{
		switch(lightState){
		//------------------------------------------------------------------------------------------------
		case OFF:
		  
			if (buttonIsPressed){
				buttonPressedCounter++;
				if (buttonPressedCounter==LIGHT_ON_DELAY){
					buttonPressedCounter = 0;
					lightA();
					lightState = LIGHT20_PHASE1; 	
				}
			}else{
				buttonPressedCounter=0;  
			}
		  
			break;
		//------------------------------------------------------------------------------------------------
		case LIGHT20_PHASE1:

			if (buttonIsPressed){
			}else{
				buttonPressedCounter=0;  
				lightState = LIGHT20_PHASE2; 	
			}
			break;
		//------------------------------------------------------------------------------------------------
		case LIGHT20_PHASE2:
		  
			if (buttonIsPressed){
				buttonPressedCounter++;
				if (buttonPressedCounter==LIGHT_CHANGE_DELAY){
					lightB();
					lightState = LIGHT40_PHASE1; 	
				}
			}else{
				buttonPressedCounter=0;  
			}
			break;
		//------------------------------------------------------------------------------------------------
		case LIGHT40_PHASE1:

			if (buttonIsPressed){
				buttonPressedCounter++;
				if (buttonPressedCounter==LIGHT_OFF_DELAY){
					lightOFF();
					lightState = OFF; 	
				}
			}else{
				buttonPressedCounter=0;  
				lightState = LIGHT40_PHASE2; 	
			}
			break;
		//------------------------------------------------------------------------------------------------
		case LIGHT40_PHASE2:
		  
			if (buttonIsPressed){
				buttonPressedCounter++;
				if (buttonPressedCounter==LIGHT_CHANGE_DELAY){
					lightC();
					lightState = LIGHT60_PHASE1; 	
				}
			}else{
				buttonPressedCounter=0;  
			}
			break;
		//------------------------------------------------------------------------------------------------
		case LIGHT60_PHASE1:

			if (buttonIsPressed){
				buttonPressedCounter++;
				if (buttonPressedCounter==LIGHT_OFF_DELAY){
					lightOFF();
					lightState = OFF; 	
				}
			}else{
				buttonPressedCounter=0;  
				lightState = LIGHT60_PHASE2; 	
			}
			break;
		//------------------------------------------------------------------------------------------------
		case LIGHT60_PHASE2:
		  
			if (buttonIsPressed){
				buttonPressedCounter++;
				if (buttonPressedCounter==LIGHT_CHANGE_DELAY){
					lightD();
					lightState = LIGHT80_PHASE1; 	
				}
			}else{
				buttonPressedCounter=0;  
			}
			break;
		//------------------------------------------------------------------------------------------------
		case LIGHT80_PHASE1:

			if (buttonIsPressed){
				buttonPressedCounter++;
				if (buttonPressedCounter==LIGHT_OFF_DELAY){
					lightOFF();
					lightState = OFF; 	
				}
			}else{
				buttonPressedCounter=0;  
				lightState = LIGHT80_PHASE2; 	
			}
			break;
		//------------------------------------------------------------------------------------------------
		case LIGHT80_PHASE2:
		  
			if (buttonIsPressed){
				buttonPressedCounter++;
				if (buttonPressedCounter==LIGHT_CHANGE_DELAY){
					lightE();
					lightState = LIGHT100_PHASE1; 	
				}
			}else{
				buttonPressedCounter=0;  
			}
			break;
		//------------------------------------------------------------------------------------------------
		case LIGHT100_PHASE1:

			if (buttonIsPressed){
				buttonPressedCounter++;
				if (buttonPressedCounter==LIGHT_OFF_DELAY){
					lightOFF();
					lightState = OFF; 	
				}
			}else{
				buttonPressedCounter=0;  
				lightState = LIGHT100_PHASE2; 	
			}
			break;
		//------------------------------------------------------------------------------------------------
		case LIGHT100_PHASE2:
		  
			if (buttonIsPressed){
				buttonPressedCounter++;
				if (buttonPressedCounter==LIGHT_CHANGE_DELAY){
					lightOFF();
					lightState = OFF; 	
				}
			}else{
				buttonPressedCounter=0;  
			}
			break;
		//------------------------------------------------------------------------------------------------
			
			
			
		}
	}	
	
	
	
  
}
//=================================================================================================

